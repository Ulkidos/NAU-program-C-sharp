﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
namespace WindowsFormsApp1
{
    class ConstantProvider
    {
        public const int OutLeft = 50;
        public const int OutTop = 50;
        public const int OutTopBox = 25;
        public const int BoxWidth = 50;
    }
    public partial class Form2 : Form
    {
        public Form2()
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        internal Form2(int textBoxesCount) { 

        }
        internal Form2(int textBoxesCount, int key)
        {
            InitializeComponent();
            TextBox[] textBoxes = new TextBox[textBoxesCount * 2 + textBoxesCount * textBoxesCount];
            this.AutoSize = true;
            for (int j = 0; j < textBoxesCount; j++)
            {
                for (int i = 0; i < textBoxesCount + 2; i++)
                {
                    textBoxes[i] = new TextBox();
                    textBoxes[i].Width = ConstantProvider.BoxWidth;
                    textBoxes[i].Left = ConstantProvider.OutLeft + i * ConstantProvider.BoxWidth;
                    textBoxes[i].Top = ConstantProvider.OutTop + j * ConstantProvider.OutTopBox;
                    textBoxes[i].Text = (i+(j* (textBoxesCount + 2))).ToString();
                    this.Controls.Add(textBoxes[i]);
                }
            }
            if(key == 1)
            {
                textBoxes[0].Text = 9999.ToString();
                textBoxes[2].Text = 1.ToString();
                textBoxes[3].Text = 1.ToString();
                textBoxes[5].Text = 2.ToString();
                textBoxes[6].Text = 3.ToString();
                textBoxes[11].Text = 1.ToString();
                //textBoxes[13+1].Text = 1.ToString();
             //   textBoxes[13+3].Text = 1.ToString();
             //   textBoxes[13+6].Text = 1.ToString();
            }
                
        }
    }
}
