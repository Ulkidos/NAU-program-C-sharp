﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class matrix
    {
        public int solid = 0;
        public int[,] solid_links = new int[10, 2];    //звязана вершина та її вага
        public bool free = true;
        public int[] min = new int[2];
        public int solid_links_num;
        public int[] solid_links_solid = new int[10];

        public matrix() {}
    }
}
