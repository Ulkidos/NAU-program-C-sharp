﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // CREATE EXCEL OBJECTS.
        Excel.Application xlApp = new Excel.Application();
        Excel.Workbook xlWorkBook;
        Excel.Worksheet xlWorkSheet;

        string sFileName;
       // int iRow, iCol = 2;
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            new Form2(int.Parse(textBox1.Text), 0).Show();
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
        // OPEN FILE DIALOG AND SELECT AN EXCEL FILE.
        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Excel File to Edit";
            openFileDialog1.FileName = "";
            openFileDialog1.Filter = "Excel File|*.xlsx;*.xls";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                sFileName = openFileDialog1.FileName;

                if (sFileName.Trim() != "")
                {
                    readExcel(sFileName);
                }
            }
        }
        //public class  matrix
        //{

        //    public int solid;
        //    public int[,] solid_links = new int[10, 2];    //звязана вершина та її вага
        //}
        // GET DATA FROM EXCEL AND POPULATE COMB0 BOX.
        private void readExcel(string sFile)
        {
            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Open(sFile);           // WORKBOOK TO OPEN THE EXCEL FILE.
            xlWorkSheet = xlWorkBook.Worksheets["Лист1"];      // NAME OF THE SHEET.

            //for (iRow = 2; iRow <= xlWorkSheet.Rows.Count; iRow++)  // START FROM THE SECOND ROW.
            //{
            //    if (xlWorkSheet.Cells[iRow, 1].value == null)
            //    {
            //        break;      // BREAK LOOP.
            //    }
            //    else
            //    {               // POPULATE COMBO BOX.
            //        cmoSheet.Items.Add(xlWorkSheet.Cells[iRow, 1].value);
            //    }
            //}


            int row = 1, column = 2;     //строка столбец
            var a = xlWorkSheet.Cells[row, column].value;


            //Sheet.Text = a.ToString);
            int[,] mas = new int[12, 14];

            /***    ЗЧИТУВАННЯ ДАНИХ З ТАБЛИЦІ EXCEL    ***/
            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 14; j++)
                {
                    a = xlWorkSheet.Cells[2 + i, 2 + j].value;
                    mas[i, j] = int.Parse((a.ToString()));
                }
            }

            xlWorkBook.Close();
            xlApp.Quit();
            //Sheet.Text = null;
            //for (int i = 0; i < 12; i++)
            //{
            //    for (int j = 0; j < 14; j++)
            //    {
            //        Sheet.Text += mas[i, j].ToString();
            //        Sheet.Text += "  ";
            //    }
            //    Sheet.Text += "\n";
            //}


            //0-11 числа 12-13 вага
            //  7   9   11
            //  3   3   3   3

            matrix[] sol = new matrix[4];
            for (int i = 0; i < 4; i++)
                sol[i] = new matrix();
            sol[0].solid = 7;
            sol[1].solid = 9;
            sol[2].solid = 11;

            sol[0].free = false;
            sol[1].free = false;
            sol[2].free = false;

            Console.WriteLine(sol[0].solid);
            for (int i = 0; sol[i].solid != 0; i++)
                sol[i].solid--;
            Console.WriteLine(sol[0].solid);

            int start_blok = 3;     //кількість заблокованих вершин

            for(int gl = 0; gl < 2; gl++)   //Кількість ітерацій спрошення
            {

                
                /***    ЗМЕНШЕННЯ ВАГИ ЗВЯЗАНИХ ВЕРШИН  ***/
                for (int k = 0; k < 3; k++)      //взяли закріплену вершину
                {
                    for (int i = 0; i < 12; i++)     // по рядам
                    {
                        if (i == sol[k].solid)      // знайшли нашу закріплену вершину
                        {
                            for (int j = 0, z = 0; j < 12; j++)        //перебираєм стовці закріпленої вершини на наявність звязків
                            {
                                if (mas[i, j] != 0)     //якщо звязок є
                                {
                                    for (int x = 0, xx = 0; x < (start_blok + gl); x++)  //чи є звязана вершина заблокованою 
                                    {
                                        if (j != sol[x].solid)   //звязана вершина не заблокована для даної вершини
                                        {
                                            xx++; 

                                            if (xx == (start_blok + gl))     //звязана вершина не заблокована
                                            {
                                                sol[k].solid_links[z, 0] = j; //з якою вершиною звязана
                                                Console.WriteLine("j = " + j);
                                                if (gl == 0)     // 1 ітерація  
                                                    sol[k].solid_links[z, 1] = mas[j, 12] - mas[i, j]; // 1 спрощення
                                                else
                                                {
                                                    if (j != sol[k].solid_links_solid[0]) 
                                                        sol[k].solid_links[z, 1] -= mas[i, j];   // всі інші ітерації  ???
                                                }
                                                
                                                Console.WriteLine(mas[j, 12] + "  " + mas[i, j]);
                                                Console.WriteLine("sol[" + k + "].solid_links[" + z + ", 1] = " + (mas[j, 12] - mas[i, j]));
                                                Console.WriteLine("z = " + z);
                                                Console.WriteLine("Else: sol[" + k + "].solid_links[" + z + ", 1] = " + sol[k].solid_links[z, 1]);
                                                sol[k].solid_links_num = z;
                                                z++;

                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }

                Console.WriteLine("\nfind min");
                for (int k = 0; k < 3; k++)     //взяли закріплену вершину
                {
                    Console.WriteLine("min_sol = " + (sol[k].solid + 1));
                    for (int z = 0; z <= sol[k].solid_links_num; z++)
                    {

                        Console.WriteLine("min = " + (sol[k].solid_links[z, 0] + 1));
                    }
                }
                Console.WriteLine("\nfind min1");

                 // for (int k1 = 0; k1 < 3; k1++)// додати заборонену вершину, вага????
                /***    ЗНАХОДЖЕННЯ ЕЛЕМЕНТА З НАЙМЕНШО ВАГОЮ   ***/
                for (int k = 0; k < 3; k++)     //взяли закріплену вершину
                {
                    for (int z = 0, min = 9999999; z <= sol[k].solid_links_num; z++) //знаходимо вершину з найменшою вагою
                    {
                        Console.WriteLine("\nmin_min = " + min);
                        if (min >= sol[k].solid_links[z, 1])
                            if (min > sol[k].solid_links[z, 1])
                            {
                                sol[k].min[0] = sol[k].solid_links[z, 0];   //збереження № вершини
                                sol[k].min[1] = sol[k].solid_links[z, 1];   //збереження ваги вершини
                                min = sol[k].solid_links[z, 1];   //збереження ваги вершини
                                Console.WriteLine("min_sol = " + (sol[k].solid + 1));
                                Console.WriteLine("min = " + sol[k].solid_links[z, 0]);
                                Console.WriteLine("min_mas = " + sol[k].solid_links[z, 1]);
                            }
                            else //if(min == sol[k].solid_links[z, 1])
                            {
                                Console.WriteLine("else");
                                if (mas[(sol[k].min[1]), 13] > mas[(sol[k].solid_links[z, 1]), 13])
                                {
                                    Console.WriteLine(sol[k].min[1] + " == " + sol[k].solid_links[z, 1] + "//" + sol[k].solid);
                                    Console.WriteLine(mas[(sol[k].min[1]), 13] + " === " + mas[(sol[k].solid_links[z, 1]), 13]);
                                    sol[k].min[0] = sol[k].solid_links[z, 0];   //збереження №вершини
                                    sol[k].min[1] = sol[k].solid_links[z, 1];   //збереження ваги вершини
                                    min = sol[k].solid_links[z, 1];   //збереження ваги вершини 
                                }
                            }
                    }

                }
            
                Console.WriteLine("\nout min");
                for (int k = 0; k < 3; k++)     //взяли закріплену вершину
                {
                    Console.WriteLine("GL =========== " + gl);
                    Console.WriteLine("min_sol = " + (sol[k].solid+1));
                    Console.WriteLine("min = " + (sol[k].min[0]+1));
                    Console.WriteLine("min_mas = " + sol[k].min[1] + "\n");
                    sol[k].solid_links_solid[gl] = sol[k].min[0];   // записуєм заборонену вершину для кожної ітерації
                }

            }

            //xlWorkBook.Close();
            //xlApp.Quit();
        }
        

            private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = xlWorkSheet.Tables[cboSheet.Text];
            
        }

        private void Sheet_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form2(12, 1).Show();
        }
    }
}
